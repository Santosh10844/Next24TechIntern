# chatbot_pairs.py
sports_convo = [
    [
        r"What is Football",
        ["A game played with a round ball by two teams of eleven players on a field with a goal at either end; the ball is moved chiefly by kicking or by using any part of the body except the hands and arms.",]
    ],
    [
        r"What is Baseball",
        ["A game played with a hard, rawhide covered ball and wooden bat by two opposing teams of nine or ten players each. It is played on a field with four bases forming a diamond-shaped circuit."]
    ],
    [
        r"What is Cricket",
        ["Cricket is a bat-and-ball game played between two teams of eleven players on a cricket field, at the centre of which is a rectangular 22-yard-long pitch with a wicket (a set of three wooden stumps) sited at each end."]
    ],  
    [
        r"Who is the greatest Football player",
        ["In my opinion, I think Lionel Messi is the GOAT",]
    ],
    [
        r"Who is the greatest Baseball player",
        ["Babe Ruth"]
    ],
    [
        r"Who is the greatest Basketball player",
        ["Michael Jordan"]
    ],
    [
        r"Who is the greatest Cricket player",
        ["Sir Donald Bradman"]
    ],
    [
        r"What is your favourite Football team",
        ["FC Barcelona"]
    ],
    [
        r"What is your favourite Basketball team",
        ["Boston Celtics"]
    ],
    [
        r"What is your favourite Baseball team",
        ["The New York Yankees"]
    ],
    [
        r"What is your favourite Cricket team",
        ["Royal Challengers Bangalore"]
    ],
]
