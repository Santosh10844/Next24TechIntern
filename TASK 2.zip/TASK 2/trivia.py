trivia_convo = [
    [
        r"Who was the 37th President of the United States?",
        ["Richard Nixon."]
    ],
    [
        r"What year was President John F. Kennedy assassinated?",
        ["1963."]
    ],
    [
        r"The Space Race was a 20th-century competition between what two Cold War rivals, for supremacy in spaceflight capability?",
        ["The Soviet Union and the United States."]
    ],
    [
        r"What was the name of the first artificial Earth satellite?",
        ["Sputnik 1."]
    ],
    [
        r"A spinning disk, in which the orientation of this axis is unaffected by tilting or rotation of the mounting, is called what?",
        ["A gyroscope."]
    ],
    [
        r"The Hubble Space Telescope, launched into low Earth orbit in 1990, is named after what American astronomer?",
        ["Edwin Hubble."]
    ],
    [
        r"What is the name of the nearest major galaxy to the Milky Way?",
        ["The Andromeda Galaxy."]
    ],
    [
        r"God Save the Queen is the national anthem of what country?",
        ["The United Kingdom of Great Britain and Northern Ireland."]
    ],
    [
        r"The Celtic Shelf, the seabed under the Celtic Sea, is a part of the continental shelf of what continent?",
        ["Europe."]
    ],
    [
        r"Dolphins use a sense, similar to sonar, to determine the location and shape of nearby items. What is this sense called?",
        ["Echolocation."]
    ],
     [
        r"What is the chemical symbol for the element gold?",
        ["Au."]
    ],
    [
        r"Which planet is known as the Red Planet?",
        ["Mars."]
    ],
    [
        r"What is the largest organ in the human body?",
        ["The skin."]
    ],
    [
        r"In what year did the Titanic sink?",
        ["1912."]
    ],
    [
        r"What is the longest river in the world?",
        ["The Nile River."]
    ],
    [
        r"What is the largest desert in the world?",
        ["The Sahara Desert."]
    ],
    [
        r"Which artist painted the Mona Lisa?",
        ["Leonardo da Vinci."]
    ],
    [
        r"Who wrote the novel '1984'?",
        ["George Orwell."]
    ],
    [
        r"What is the capital city of Australia?",
        ["Canberra."]
    ],
    [
        r"Which mammal lays eggs?",
        ["The platypus."]
    ]
]
